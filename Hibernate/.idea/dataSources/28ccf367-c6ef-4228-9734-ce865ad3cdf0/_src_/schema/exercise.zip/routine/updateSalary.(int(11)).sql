CREATE PROCEDURE exercise.updateSalary(IN param1 INT)
  begin
update cust_id
set cust_id = 8
where cust_id = param1
;
end;
