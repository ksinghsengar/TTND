CREATE PROCEDURE exercise.updateN(IN param1 VARCHAR(10))
  begin
 update customer
 set cust_name = "H"
 where cust_name = param1;
end;
