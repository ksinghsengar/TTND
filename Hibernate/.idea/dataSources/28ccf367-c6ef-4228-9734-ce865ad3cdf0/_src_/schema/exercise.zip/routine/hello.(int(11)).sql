CREATE FUNCTION exercise.hello(Id INT)
  RETURNS CHAR(50)
  return 'world';
