CREATE PROCEDURE exercise.updateName(IN param1 INT)
  begin
 update customer
 set cust_id = 8
 where cust_id = param1;
end;
